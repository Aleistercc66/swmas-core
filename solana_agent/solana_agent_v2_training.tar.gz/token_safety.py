#!/usr/bin/env python3
"""
Token Safety Analyzer - Rug Pull & Scam Detection
Αναλύει tokens για red flags πριν το entry.
"""

import asyncio
import aiohttp
import json
import time
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field


@dataclass
class SafetyReport:
    """Αναφορά ασφάλειας token."""
    token_address: str
    symbol: str
    
    # Risk flags
    is_mintable: bool = True  # Can dev mint more?
    is_burnable: bool = False  # Can dev burn?
    has_honeypot: bool = False  # Can you sell?
    has_blacklist: bool = False  # Can dev blacklist wallets?
    has_pause_function: bool = False  # Can trading be paused?
    ownership_renounced: bool = False  # Is contract immutable?
    
    # Dev analysis
    dev_wallet: str = ""
    dev_history: List[Dict] = field(default_factory=list)
    dev_rug_count: int = 0
    dev_success_count: int = 0
    
    # Liquidity analysis
    liquidity_locked: bool = False
    liquidity_lock_duration: float = 0.0  # days
    lp_tokens_burned: bool = False
    
    # Holder analysis
    holder_count: int = 0
    top_holder_pct: float = 0.0  # % held by top wallet
    top_5_holders_pct: float = 0.0  # % held by top 5
    
    # Overall score (0-100, lower = safer)
    risk_score: float = 100.0
    is_safe: bool = False
    
    # Red flags
    red_flags: List[str] = field(default_factory=list)


class TokenSafetyAnalyzer:
    """
    Αναλυτής ασφάλειας token.
    Ελέγχει για honeypots, rugs, malicious code.
    """
    
    def __init__(self):
        self.known_scam_patterns = [
            "honeypot",
            "blacklist",
            "mint",
            "pause",
            "selfdestruct",
        ]
        
        # Known rug pull devs (would be populated from database)
        self.known_rugger_wallets: set = set()
        
        # Safety thresholds
        self.min_holders_for_safety = 50
        self.max_top_holder_pct = 20.0  # Max % one wallet can hold
        self.max_top5_holder_pct = 50.0  # Max % top 5 can hold
        self.min_liquidity_lock_days = 30
        
        self.load_known_ruggers()
    
    def load_known_ruggers(self):
        """Load known rug pull wallets."""
        try:
            with open("known_ruggers.json", 'r') as f:
                data = json.load(f)
                self.known_rugger_wallets = set(data.get("wallets", []))
        except FileNotFoundError:
            pass
    
    async def analyze_token(self, session: aiohttp.ClientSession,
                           token_address: str) -> SafetyReport:
        """Full safety analysis ενός token."""
        
        report = SafetyReport(token_address=token_address, symbol="")
        
        # Fetch token metadata
        metadata = await self._fetch_token_metadata(session, token_address)
        if metadata:
            report.symbol = metadata.get("symbol", "UNKNOWN")
            report.is_mintable = metadata.get("mint_authority", None) is not None
            report.has_pause_function = metadata.get("freeze_authority", None) is not None
        
        # Check contract on Solscan
        contract_analysis = await self._analyze_contract(session, token_address)
        if contract_analysis:
            report.has_honeypot = contract_analysis.get("is_honeypot", False)
            report.has_blacklist = contract_analysis.get("has_blacklist", False)
            report.ownership_renounced = contract_analysis.get("ownership_renounced", False)
        
        # Analyze holders
        holders = await self._fetch_holder_data(session, token_address)
        if holders:
            report.holder_count = len(holders)
            if holders:
                report.top_holder_pct = holders[0].get("pct", 0)
                report.top_5_holders_pct = sum(h.get("pct", 0) for h in holders[:5])
        
        # Check liquidity
        liquidity = await self._check_liquidity_lock(session, token_address)
        if liquidity:
            report.liquidity_locked = liquidity.get("locked", False)
            report.liquidity_lock_duration = liquidity.get("lock_duration_days", 0)
            report.lp_tokens_burned = liquidity.get("lp_burned", False)
        
        # Calculate risk score
        report.risk_score = self._calculate_risk_score(report)
        report.is_safe = report.risk_score < 50
        
        # Generate red flags
        report.red_flags = self._generate_red_flags(report)
        
        return report
    
    def _calculate_risk_score(self, report: SafetyReport) -> float:
        """Υπολογισμός risk score."""
        score = 0.0
        
        # Contract risks
        if report.has_honeypot:
            score += 50  # CRITICAL
        if report.has_blacklist:
            score += 25
        if report.is_mintable:
            score += 20
        if report.has_pause_function:
            score += 15
        if not report.ownership_renounced:
            score += 10
        
        # Holder concentration
        if report.top_holder_pct > 50:
            score += 30
        elif report.top_holder_pct > 20:
            score += 15
        
        if report.top_5_holders_pct > 80:
            score += 20
        elif report.top_5_holders_pct > 50:
            score += 10
        
        # Liquidity
        if not report.liquidity_locked and not report.lp_tokens_burned:
            score += 15
        elif report.liquidity_locked and report.liquidity_lock_duration < 7:
            score += 10
        
        # Holder count
        if report.holder_count < 10:
            score += 20
        elif report.holder_count < 50:
            score += 10
        
        return min(100, score)
    
    def _generate_red_flags(self, report: SafetyReport) -> List[str]:
        """Generate list of red flags."""
        flags = []
        
        if report.has_honeypot:
            flags.append("🔴 HONEYPOT - Cannot sell!")
        if report.has_blacklist:
            flags.append("🟠 Has blacklist function")
        if report.is_mintable:
            flags.append("🟠 Dev can mint more tokens")
        if report.has_pause_function:
            flags.append("🟠 Trading can be paused")
        if not report.ownership_renounced:
            flags.append("🟡 Ownership not renounced")
        if report.top_holder_pct > 20:
            flags.append(f"🟡 Top holder has {report.top_holder_pct:.1f}%")
        if not report.liquidity_locked and not report.lp_tokens_burned:
            flags.append("🟡 Liquidity not locked")
        if report.holder_count < 50:
            flags.append(f"🟡 Only {report.holder_count} holders")
        
        return flags
    
    async def _fetch_token_metadata(self, session: aiohttp.ClientSession,
                                    token_address: str) -> Optional[Dict]:
        """Fetch token metadata."""
        try:
            # Use Solana RPC or external API
            async with session.get(
                f"https://api.dexscreener.com/latest/dex/tokens/{token_address}",
                timeout=aiohttp.ClientTimeout(total=10)
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    pairs = data.get("pairs", [])
                    if pairs:
                        return {
                            "symbol": pairs[0].get("baseToken", {}).get("symbol", ""),
                        }
        except Exception:
            pass
        return None
    
    async def _analyze_contract(self, session: aiohttp.ClientSession,
                               token_address: str) -> Optional[Dict]:
        """Analyze contract for malicious code."""
        # This would integrate with RugCheck API or similar
        try:
            async with session.get(
                f"https://api.rugcheck.xyz/v1/tokens/{token_address}/report",
                timeout=aiohttp.ClientTimeout(total=10)
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return {
                        "is_honeypot": data.get("rugged", False),
                        "has_blacklist": any("blacklist" in str(r).lower() for r in data.get("risks", [])),
                        "ownership_renounced": data.get("owner renounced", False),
                    }
        except Exception:
            pass
        return None
    
    async def _fetch_holder_data(self, session: aiohttp.ClientSession,
                                  token_address: str) -> Optional[List[Dict]]:
        """Fetch top holders."""
        # Would use Solscan or Birdeye API
        return None
    
    async def _check_liquidity_lock(self, session: aiohttp.ClientSession,
                                     token_address: str) -> Optional[Dict]:
        """Check if liquidity is locked."""
        return None
    
    def quick_safety_check(self, token_data: Dict) -> Dict:
        """Quick safety check χωρίς API calls."""
        
        red_flags = []
        score = 0
        
        # Liquidity check
        liquidity = token_data.get("liquidity", 0)
        if liquidity < 10000:
            red_flags.append("Very low liquidity")
            score += 20
        elif liquidity < 50000:
            score += 10
        
        # Volume check
        volume = token_data.get("volume_24h", 0)
        if volume < 1000:
            red_flags.append("Very low volume")
            score += 15
        
        # Price stability
        changes = token_data.get("changes", {})
        h24 = abs(changes.get("h24", 0))
        if h24 > 1000:
            red_flags.append("Extreme 24h volatility")
            score += 10
        
        return {
            "score": min(100, score),
            "is_safe": score < 40,
            "red_flags": red_flags,
        }


if __name__ == "__main__":
    analyzer = TokenSafetyAnalyzer()
    print("🛡️ Token Safety Analyzer initialized")
    print("   Checks: honeypot, blacklist, mint, pause, liquidity lock, holder concentration")
