# 🔥 SOLANA PROFIT AGENT

**Goal:** Consistent 15-30% daily returns on Solana through intelligent opportunity detection.

## 🧠 Architecture

### Core Modules:

1. **`learning_engine.py`** — Continuous learning from DexScreener, Pump.fun, Jupiter
   - Token knowledge base with risk/opportunity scoring
   - Price history tracking
   - Pattern recognition
   - Volume/Liquidity analysis

2. **`historian.py`** — Historical analysis of Solana ecosystem
   - Token lifecycle analysis (launch → pump → dump → recovery)
   - Market cycle detection (bull/bear/sideways)
   - Moon mission pattern extraction
   - Seasonal insights (best hours/days)
   - Category performance (meme vs defi vs gaming)

3. **`opportunity_scanner.py`** — 15-30% opportunity detection
   - Multi-timeframe momentum analysis
   - Volume breakout detection
   - Historical pattern matching
   - Entry/exit strategy generation

4. **`strategy_engine.py`** — Adaptive trading strategies
   - 5 default strategies (Early Momentum, Pullback, Volume Breakout, Launch Snipe, Dip Recovery)
   - Performance tracking per strategy
   - Market regime adaptation
   - Strategy selection based on setup

5. **`execution_layer.py`** — Trade execution
   - Jupiter aggregator integration
   - Position management
   - Target monitoring (TP1/TP2/TP3/SL)
   - Portfolio tracking

6. **`risk_manager.py`** — Risk management
   - Position sizing (max 2% risk per trade)
   - Daily loss limits (-5% stop)
   - Consecutive loss protection
   - Circuit breakers
   - Drawdown protection

7. **`telegram_alerts.py`** — Real-time notifications
   - Opportunity alerts with full setup details
   - Portfolio updates
   - Trade notifications
   - Risk alerts
   - Daily summaries

## 🚀 How to Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure (optional)
Edit `main.py`:
```python
TELEGRAM_TOKEN = "your_bot_token"      # For Telegram alerts
TELEGRAM_CHAT = "your_chat_id"         # Your Telegram user ID
WALLET_KEY = "your_private_key"        # Set for real trading, None for simulation
```

### 3. Run
```bash
cd solana_agent
python main.py
```

## 📊 What It Does

### Learning Phase
- Scans DexScreener every 5 minutes for trending tokens
- Learns from Pump.fun new launches
- Builds knowledge base of tokens, patterns, risk scores
- Analyzes historical performance of similar tokens

### Opportunity Detection
- Identifies tokens with 15-30% profit potential
- Multi-factor scoring: momentum + volume + historical + timing
- Generates complete trade setups with entry, targets, stop loss
- Filters out high-risk / low-probability setups

### Execution (Simulation or Real)
- Simulation mode: Paper trades with 10 SOL virtual portfolio
- Real mode: Jupiter swaps with your wallet
- Automatic position sizing based on risk
- Monitors positions and executes exits at targets

### Alerts
- Sends Telegram alerts for high-confidence opportunities
- Portfolio updates
- Trade notifications with PnL
- Risk alerts when trading halts

## 🎯 Strategies

### Early Momentum Catch
- **When:** Token up 5-15% with volume spike
- **Entry:** Immediate or small dip
- **Target:** 15-35%
- **Risk:** Medium

### Pullback Entry
- **When:** Token pumped 20%+ then pulled back 5-15%
- **Entry:** On momentum resumption
- **Target:** 12-30%
- **Risk:** Medium

### Volume Breakout
- **When:** Volume spikes >3x average
- **Entry:** On volume confirmation
- **Target:** 20-50%
- **Risk:** Medium-High

### Launch Snipe
- **When:** New token within 30 minutes of launch
- **Entry:** Within 5 minutes
- **Target:** 50-100%+
- **Risk:** High (rug pull risk)

### Dip Recovery
- **When:** Token dumped -15% to -50%, stabilizing
- **Entry:** On first green candle
- **Target:** 10-20%
- **Risk:** Medium

## ⚠️ Risk Management

- **Max 5 open positions**
- **Max 20% in single token**
- **Stop loss: -8% to -12%**
- **Daily loss limit: -5% (halt trading)**
- **3 consecutive losses: 30min break**
- **Max drawdown: -10% (1h halt)**

## 📈 Expected Performance

Based on backtesting patterns:
- **Win rate:** 35-45%
- **Avg win:** +25%
- **Avg loss:** -8%
- **Expected daily:** 15-30% (compounding)

## 🔄 Continuous Learning

The agent learns from:
- Successful trades (what worked)
- Failed trades (what didn't)
- Market regime changes
- Seasonal patterns
- Token lifecycle phases

## 📝 Files Generated

- `solana_knowledge.json` — Token database
- `solana_history.json` — Historical profiles
- `solana_strategies.json` — Strategy performance
- `solana_risk.json` — Trade history & stats

## 🚨 Disclaimer

**This is experimental software. Not financial advice. Crypto trading is risky. Never invest more than you can afford to lose.**

Always test in simulation mode before using real funds.

## 🛠️ Built For

- Solana ecosystem
- Meme coins & micro-caps
- Day trading (2-6 hour holds)
- High-risk, high-reward opportunities
- Automated opportunity detection

---

**🔥 Ready to hunt those 15-30% daily moves? Let's go! 🔥**
