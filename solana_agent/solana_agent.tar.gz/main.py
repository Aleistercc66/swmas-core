#!/usr/bin/env python3
"""
Solana Profit Agent - Main Orchestrator
Κεντρικό σύστημα που συνδυάζει:
- Learning Engine (DexScreener, Pump.fun, Jupiter)
- Historical Analysis (ιστορικά patterns)
- Opportunity Scanner (15-30% targets)
- Strategy Engine (adaptive strategies)
- Risk Manager (position sizing, stops)
- Execution Layer (Jupiter swaps)
- Telegram Alerts (real-time notifications)

GOAL: Consistent 15-30% daily returns on Solana
"""

import asyncio
import aiohttp
import json
import time
import signal
import sys
from typing import Dict, List, Optional
from datetime import datetime

# Import our modules
from learning_engine import SolanaKnowledgeBase
from historian import SolanaHistorian
from opportunity_scanner import OpportunityScanner, TradeSetup
from strategy_engine import StrategyEngine
from execution_layer import ExecutionEngine
from risk_manager import RiskManager
from telegram_alerts import TelegramAlerter, AlertConfig


class SolanaProfitAgent:
    """
    Κύριος agent που συντονίζει όλα τα subsystems.
    """
    
    def __init__(self, telegram_token: Optional[str] = None, 
                 telegram_chat: Optional[str] = None,
                 wallet_key: Optional[str] = None):
        
        print("🔥 INITIALIZING SOLANA PROFIT AGENT 🔥")
        print("=" * 50)
        
        # Initialize all subsystems
        self.kb = SolanaKnowledgeBase()
        self.historian = SolanaHistorian()
        self.scanner = OpportunityScanner(self.kb, self.historian)
        self.strategy_engine = StrategyEngine()
        self.execution = ExecutionEngine(wallet_key)
        self.risk = RiskManager()
        
        # Telegram alerts
        if telegram_token and telegram_chat:
            alert_config = AlertConfig(
                bot_token=telegram_token,
                chat_id=telegram_chat,
            )
            self.alerter = TelegramAlerter(alert_config)
        else:
            self.alerter = None
        
        # Session state
        self.running = False
        self.scan_count = 0
        self.last_scan_time = 0
        self.session_start = time.time()
        
        # Portfolio simulation (until real wallet connected)
        self.simulation_mode = wallet_key is None
        self.simulated_portfolio_value = 10.0  # 10 SOL simulated
        
        print("✅ All subsystems initialized!")
        print(f"   Simulation mode: {self.simulation_mode}")
        print(f"   Telegram alerts: {'Enabled' if self.alerter else 'Disabled'}")
        print("=" * 50)
    
    async def run(self):
        """Main run loop."""
        self.running = True
        
        print("\n🚀 AGENT STARTED - Hunting for 15-30% opportunities...")
        print(f"   Started at: {datetime.now().strftime('%H:%M:%S')}")
        
        async with aiohttp.ClientSession() as session:
            # Main loop
            while self.running:
                try:
                    await self._main_cycle(session)
                except Exception as e:
                    print(f"❌ Main cycle error: {e}")
                    await asyncio.sleep(60)
    
    async def _main_cycle(self, session: aiohttp.ClientSession):
        """Ένας πλήρης κύκλος: scan → analyze → alert."""
        
        cycle_start = time.time()
        print(f"\n{'='*50}")
        print(f"🔄 CYCLE #{self.scan_count + 1} | {datetime.now().strftime('%H:%M:%S')}")
        print(f"{'='*50}")
        
        # 1. LEARN (update knowledge base)
        print("\n📚 PHASE 1: LEARNING")
        try:
            dex_opps = await self.kb.learn_from_dexscreener(session)
            pump_launches = await self.kb.learn_from_pumpfun(session)
            print(f"   ✅ Knowledge updated: {len(dex_opps)} opportunities, {len(pump_launches)} new launches")
        except Exception as e:
            print(f"   ⚠️ Learning error: {e}")
        
        # 2. SCAN (find opportunities)
        print("\n🔍 PHASE 2: SCANNING")
        try:
            opportunities = await self.scanner.scan_for_opportunities()
            print(f"   ✅ Found {len(opportunities)} opportunities")
        except Exception as e:
            print(f"   ⚠️ Scan error: {e}")
            opportunities = []
        
        # 3. ANALYZE & ALERT (send best to Telegram)
        print("\n📨 PHASE 3: ANALYZING & ALERTING")
        if opportunities and self.alerter:
            for opp in opportunities[:3]:  # Top 3
                try:
                    sent = await self.alerter.send_opportunity_alert(session, opp)
                    if sent:
                        print(f"   📨 Alert sent: {opp.symbol} (+{opp.target_return:.1f}%)")
                except Exception as e:
                    print(f"   ⚠️ Alert error: {e}")
        elif opportunities:
            # Console output if no Telegram
            for opp in opportunities[:3]:
                print(f"\n   🎯 {opp.symbol}")
                print(f"      Target: +{opp.target_return:.1f}%")
                print(f"      Score: {opp.opportunity_score:.0f}/100")
                print(f"      Strategy: {opp.entry_strategy}")
        else:
            print("   ℹ️ No opportunities found this cycle")
        
        # 4. PORTFOLIO CHECK
        print("\n💼 PHASE 4: PORTFOLIO")
        try:
            portfolio = self.execution.get_portfolio_status()
            print(f"   Positions: {portfolio['total_positions']}")
            print(f"   Daily PnL: {portfolio['daily_pnl_sol']:+.3f} SOL")
            
            if portfolio['total_positions'] > 0 and self.alerter:
                await self.alerter.send_portfolio_update(session, portfolio)
        except Exception as e:
            print(f"   ⚠️ Portfolio error: {e}")
        
        # 5. RISK CHECK
        print("\n🛡️ PHASE 5: RISK CHECK")
        can_trade, risk_msg = self.risk.can_trade()
        if not can_trade:
            print(f"   🚫 {risk_msg}")
            if self.alerter:
                await self.alerter.send_risk_alert(session, risk_msg)
        else:
            print(f"   ✅ Trading allowed | {risk_msg}")
        
        # 6. STATS
        cycle_time = time.time() - cycle_start
        self.scan_count += 1
        self.last_scan_time = time.time()
        
        print(f"\n📊 CYCLE COMPLETE")
        print(f"   Duration: {cycle_time:.1f}s")
        print(f"   Total scans: {self.scan_count}")
        print(f"   Session uptime: {(time.time() - self.session_start)/60:.0f}m")
        
        # Wait before next cycle
        wait_time = max(0, 300 - cycle_time)  # 5 min between cycles
        if wait_time > 0:
            print(f"   Next cycle in {wait_time:.0f}s...")
            await asyncio.sleep(wait_time)
    
    async def execute_trade(self, setup: TradeSetup):
        """Εκτέλεση trade (simulation or real)."""
        
        # Risk validation
        portfolio = self.execution.get_portfolio_status()
        valid, msg, position_size = self.risk.validate_setup(
            setup,
            portfolio.get('available_sol', self.simulated_portfolio_value),
            portfolio.get('total_positions', 0)
        )
        
        if not valid:
            print(f"❌ Trade rejected: {msg}")
            return None
        
        print(f"\n🎯 EXECUTING TRADE: {setup.symbol}")
        print(f"   Size: {position_size:.3f} SOL")
        print(f"   Strategy: {self.strategy_engine.active_strategy or 'default'}")
        
        if self.simulation_mode:
            # Simulate trade
            print(f"   🎮 SIMULATION MODE - Paper trade executed")
            
            # Create simulated position
            position = await self.execution.execute_entry(
                None,  # No session needed for sim
                setup,
                self.simulated_portfolio_value
            )
            
            if position:
                print(f"   ✅ Position opened (simulated)")
                return position
        else:
            # Real trade via Jupiter
            async with aiohttp.ClientSession() as session:
                position = await self.execution.execute_entry(
                    session,
                    setup,
                    self.execution.total_sol_balance
                )
                
                if position:
                    print(f"   ✅ Position opened (real)")
                    return position
        
        return None
    
    async def monitor_and_manage(self):
        """Monitor ανοιχτές θέσεις και manage exits."""
        
        async with aiohttp.ClientSession() as session:
            while self.running:
                try:
                    # Fetch prices and check targets
                    triggered = await self.execution.monitor_positions(
                        session,
                        self._fetch_token_price
                    )
                    
                    for trigger in triggered:
                        print(f"\n🎯 TARGET HIT: {trigger['token']} | {trigger['trigger']} | {trigger['pnl_pct']:+.1f}%")
                        
                        # Execute exit
                        result = await self.execution.execute_exit(
                            trigger['address'],
                            trigger['trigger'],
                            session
                        )
                        
                        if result:
                            # Record for learning
                            self.risk.record_trade(
                                trigger['token'],
                                result.get('entry_price', 0),
                                result.get('exit_price', 0),
                                result.get('position_size', 0),
                                trigger['trigger']
                            )
                            
                            # Notify
                            if self.alerter:
                                await self.alerter.send_trade_notification(session, {
                                    **result,
                                    "symbol": trigger['token'],
                                    "pnl_pct": trigger['pnl_pct'],
                                    "reason": trigger['trigger'],
                                })
                    
                    # Sleep
                    await asyncio.sleep(30)  # Check every 30 seconds
                    
                except Exception as e:
                    print(f"❌ Monitor error: {e}")
                    await asyncio.sleep(60)
    
    async def _fetch_token_price(self, token_address: str) -> Optional[float]:
        """Fetch current token price."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"https://api.dexscreener.com/latest/dex/tokens/{token_address}",
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        pairs = data.get("pairs", [])
                        if pairs:
                            return float(pairs[0].get("priceUsd", 0))
        except Exception as e:
            print(f"❌ Price fetch error: {e}")
        return None
    
    def generate_report(self) -> Dict:
        """Generate comprehensive agent report."""
        
        return {
            "session": {
                "start_time": datetime.fromtimestamp(self.session_start).isoformat(),
                "uptime_hours": (time.time() - self.session_start) / 3600,
                "total_scans": self.scan_count,
            },
            "knowledge": {
                "tokens_tracked": len(self.kb.tokens),
                "patterns_learned": len(self.kb.patterns),
                "hot_tokens": len(self.kb.hot_tokens),
            },
            "history": {
                "profiles": len(self.historian.token_profiles),
                "cycles": len(self.historian.market_cycles),
                "moon_missions": len([p for p in self.historian.token_profiles.values() if p.is_moon_mission]),
            },
            "opportunities": {
                "active_setups": len(self.scanner.active_setups),
                "executed": len(self.scanner.executed_setups),
                "best_current": self.scanner.get_best_opportunity().symbol if self.scanner.get_best_opportunity() else None,
            },
            "execution": self.execution.get_portfolio_status(),
            "risk": self.risk.get_risk_report(),
            "strategies": self.strategy_engine.generate_strategy_report(),
        }
    
    def stop(self):
        """Graceful shutdown."""
        print("\n🛑 STOPPING AGENT...")
        self.running = False
        
        # Save all data
        self.kb.save_knowledge()
        self.historian.save_history()
        self.strategy_engine.save_strategies()
        self.risk.save_risk_data()
        
        # Generate final report
        report = self.generate_report()
        print(f"\n📊 FINAL REPORT:")
        print(json.dumps(report, indent=2, default=str))
        
        print("\n👋 Agent stopped. Data saved.")


def signal_handler(agent: SolanaProfitAgent):
    """Handle Ctrl+C gracefully."""
    def handler(signum, frame):
        print("\n⚠️ Interrupted by user")
        agent.stop()
        sys.exit(0)
    return handler


async def main():
    """Entry point."""
    
    # Configuration
    TELEGRAM_TOKEN = "YOUR_BOT_TOKEN"  # Replace with your token
    TELEGRAM_CHAT = "YOUR_CHAT_ID"     # Replace with your chat ID
    WALLET_KEY = None                  # Set for real trading, None for simulation
    
    # Create agent
    agent = SolanaProfitAgent(
        telegram_token=TELEGRAM_TOKEN if TELEGRAM_TOKEN != "YOUR_BOT_TOKEN" else None,
        telegram_chat=TELEGRAM_CHAT if TELEGRAM_CHAT != "YOUR_CHAT_ID" else None,
        wallet_key=WALLET_KEY,
    )
    
    # Setup signal handler
    signal.signal(signal.SIGINT, signal_handler(agent))
    
    # Run
    try:
        await agent.run()
    except Exception as e:
        print(f"❌ Fatal error: {e}")
        agent.stop()


if __name__ == "__main__":
    asyncio.run(main())
