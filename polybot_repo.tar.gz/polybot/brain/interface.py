"""Brain interface — swappable strategy module."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from decimal import Decimal
from typing import List, Optional


@dataclass(frozen=True)
class Portfolio:
    """Current portfolio snapshot."""
    total_usdc: Decimal
    available_usdc: Decimal
    positions: dict  # market_id -> {outcome: size, avg_price, pnl}
    open_orders: List[dict]
    daily_pnl: Decimal
    daily_loss_pct: Optional[Decimal] = None


@dataclass(frozen=True)
class TradeDecision:
    """A single trade decision produced by the brain."""
    market_id: str
    outcome: str  # "Yes" or "No"
    side: str  # "BUY" or "SELL"
    size: Decimal  # In outcome tokens / USDC
    price: Optional[Decimal] = None  # Limit price; None = market order
    order_type: str = "LIMIT"  # LIMIT or MARKET
    time_in_force: str = "GTC"  # GTC, IOC, FOK
    confidence: int = 0  # 0-100
    reason: str = ""


class BrainInterface(ABC):
    """Abstract base for all trading brains.

    Implement `decide()` with your strategy logic.
    The engine calls this every cycle with fresh MarketState + Portfolio.
    """

    @abstractmethod
    def decide(self, state, portfolio: Portfolio) -> List[TradeDecision]:
        """Given market state and portfolio, return trade decisions.

        Args:
            state: MarketState (or dict of MarketState for multi-market strategies).
            portfolio: Current portfolio snapshot.

        Returns:
            List of TradeDecision objects.
        """
        ...

    def on_init(self) -> None:
        """Called once at startup — load models, warm caches, etc."""
        pass

    def on_shutdown(self) -> None:
        """Called on graceful shutdown — save state, close resources."""
        pass
