"""Example brain — does nothing, just logs. Copy this to build your own."""

import logging
from decimal import Decimal
from typing import List

from brain.interface import BrainInterface, Portfolio, TradeDecision

logger = logging.getLogger(__name__)


class ExampleBrain(BrainInterface):
    """Placeholder brain that logs and returns no trades.

    This demonstrates the interface. The user swaps this out for real logic.
    """

    def __init__(self, buy_threshold: float = 0.65, sell_threshold: float = 0.35):
        self.buy_threshold = buy_threshold
        self.sell_threshold = sell_threshold

    def on_init(self) -> None:
        logger.info("ExampleBrain initialized — thresholds: buy=%.2f sell=%.2f", self.buy_threshold, self.sell_threshold)

    def decide(self, state, portfolio: Portfolio) -> List[TradeDecision]:
        """Log the state, return empty list."""
        # For multi-market, state is a dict; for single, it's a MarketState
        markets = state if isinstance(state, dict) else {state.market.id: state}

        logger.debug(
            "Brain cycle | markets=%d portfolio=%s",
            len(markets),
            portfolio,
        )

        for m_id, st in markets.items():
            yes_price = st.market.outcome_prices.get("Yes")
            if yes_price is None:
                continue

            # Placeholder logic: would buy if Yes > threshold
            if yes_price > Decimal(str(self.buy_threshold)):
                logger.info("[SIGNAL] %s Yes=%.2f > buy_threshold", m_id, yes_price)
            elif yes_price < Decimal(str(self.sell_threshold)):
                logger.info("[SIGNAL] %s Yes=%.2f < sell_threshold", m_id, yes_price)

        return []  # No real trades — placeholder!
