"""Telegram bot for notifications and remote control."""

import asyncio
import logging
from typing import Optional

from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

from config.settings import settings
from scheduler.orchestrator import orchestrator

logger = logging.getLogger(__name__)


class TelegramBot:
    """Telegram bot for trade alerts, errors, and remote commands."""

    def __init__(self):
        self.app: Optional[Application] = None
        self._running = False

    async def _start_bot(self) -> None:
        if not settings.TELEGRAM_BOT_TOKEN:
            logger.warning("No TELEGRAM_BOT_TOKEN — Telegram bot disabled")
            return

        self.app = Application.builder().token(settings.TELEGRAM_BOT_TOKEN).build()

        # Handlers
        self.app.add_handler(CommandHandler("start", self._cmd_start))
        self.app.add_handler(CommandHandler("status", self._cmd_status))
        self.app.add_handler(CommandHandler("positions", self._cmd_positions))
        self.app.add_handler(CommandHandler("pnl", self._cmd_pnl))
        self.app.add_handler(CommandHandler("pause", self._cmd_pause))
        self.app.add_handler(CommandHandler("resume", self._cmd_resume))
        self.app.add_handler(CommandHandler("killall", self._cmd_killall))
        self.app.add_handler(CommandHandler("confirm_live", self._cmd_confirm_live))

        await self.app.initialize()
        await self.app.start()
        self._running = True
        logger.info("Telegram bot started")

    # ── Command Handlers ──

    async def _cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        await update.message.reply_text(
            "🤖 PolyBot Remote Control\n\n"
            "/status — System status\n"
            "/positions — Open positions\n"
            "/pnl — P&L summary\n"
            "/pause — Pause trading\n"
            "/resume — Resume trading\n"
            "/killall — EMERGENCY STOP\n"
            "/confirm_live — Ready for live trading"
        )

    async def _cmd_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        msg = await orchestrator.command_status()
        await update.message.reply_text(f"```{msg}```", parse_mode="Markdown")

    async def _cmd_positions(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        msg = await orchestrator.command_positions()
        await update.message.reply_text(msg)

    async def _cmd_pnl(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        msg = await orchestrator.command_pnl()
        await update.message.reply_text(msg)

    async def _cmd_pause(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        msg = await orchestrator.command_pause()
        await update.message.reply_text(msg)

    async def _cmd_resume(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        msg = await orchestrator.command_resume()
        await update.message.reply_text(msg)

    async def _cmd_killall(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        await update.message.reply_text("🚨 EMERGENCY STOP invoked!")
        msg = await orchestrator.command_killall()
        await update.message.reply_text(msg)

    async def _cmd_confirm_live(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        msg = await orchestrator.confirm_live()
        await update.message.reply_text(msg)

    # ── Public API ──

    async def start(self) -> None:
        if not settings.TELEGRAM_BOT_TOKEN:
            return
        asyncio.create_task(self._start_bot())

    async def stop(self) -> None:
        if self.app and self._running:
            await self.app.stop()
            self._running = False

    async def send_message(self, text: str) -> None:
        if not self.app or not settings.TELEGRAM_CHAT_ID:
            return
        try:
            await self.app.bot.send_message(chat_id=settings.TELEGRAM_CHAT_ID, text=text)
        except Exception:
            logger.debug("Telegram send failed")

    async def notify_trade(self, decision) -> None:
        msg = (
            f"📈 Trade Executed\n"
            f"Market: {decision.market_id}\n"
            f"Side: {decision.side} {decision.outcome}\n"
            f"Size: {decision.size} USDC\n"
            f"Confidence: {decision.confidence}/100"
        )
        await self.send_message(msg)

    async def notify_error(self, error: str) -> None:
        await self.send_message(f"⚠️ Error: {error}")


# Singleton
telegram = TelegramBot()
