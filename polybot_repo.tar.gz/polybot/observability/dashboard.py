"""FastAPI dashboard for real-time monitoring."""

import asyncio
import json
import logging
from datetime import datetime
from typing import Any, Dict, List

from fastapi import FastAPI, HTTPException, Header
from fastapi.responses import JSONResponse

from config.settings import settings

logger = logging.getLogger(__name__)

# Global mutable state (populated by scheduler)
dashboard_state: Dict[str, Any] = {
    "heartbeats": [],
    "last_decisions": [],
    "pnl_history": [],
    "positions": [],
    "status": "unknown",
    "dry_run": settings.DRY_RUN,
}

app = FastAPI(title="PolyBot Dashboard", version="1.0.0")


async def _verify_auth(authorization: str = Header(None)) -> bool:
    if not settings.DASHBOARD_AUTH_TOKEN:
        return True
    if not authorization:
        return False
    token = authorization.replace("Bearer ", "") if authorization.startswith("Bearer ") else authorization
    return token == settings.DASHBOARD_AUTH_TOKEN


@app.get("/health")
async def health():
    """Health endpoint for systemd/Docker."""
    last_hb = dashboard_state["heartbeats"][-1] if dashboard_state["heartbeats"] else None
    return {
        "status": "ok" if last_hb else "starting",
        "last_heartbeat": last_hb,
        "dry_run": settings.DRY_RUN,
        "brain": settings.BRAIN_MODULE,
    }


@app.get("/api/status")
async def api_status(authorization: str = Header(None)):
    if not await _verify_auth(authorization):
        raise HTTPException(status_code=401, detail="Unauthorized")
    return {
        "status": dashboard_state["status"],
        "dry_run": dashboard_state["dry_run"],
        "brain_module": settings.BRAIN_MODULE,
        "last_decisions_count": len(dashboard_state["last_decisions"]),
    }


@app.get("/api/heartbeats")
async def api_heartbeats(authorization: str = Header(None)):
    if not await _verify_auth(authorization):
        raise HTTPException(status_code=401, detail="Unauthorized")
    return dashboard_state["heartbeats"]


@app.get("/api/decisions")
async def api_decisions(authorization: str = Header(None)):
    if not await _verify_auth(authorization):
        raise HTTPException(status_code=401, detail="Unauthorized")
    return dashboard_state["last_decisions"]


@app.get("/api/pnl")
async def api_pnl(authorization: str = Header(None)):
    if not await _verify_auth(authorization):
        raise HTTPException(status_code=401, detail="Unauthorized")
    return dashboard_state["pnl_history"]


@app.get("/api/positions")
async def api_positions(authorization: str = Header(None)):
    if not await _verify_auth(authorization):
        raise HTTPException(status_code=401, detail="Unauthorized")
    return dashboard_state["positions"]


def start_dashboard() -> None:
    """Start uvicorn in a background thread."""
    import uvicorn
    import threading

    def run():
        uvicorn.run(app, host=settings.DASHBOARD_HOST, port=settings.DASHBOARD_PORT, log_level="warning")

    thread = threading.Thread(target=run, daemon=True)
    thread.start()
    logger.info("Dashboard started on http://%s:%d", settings.DASHBOARD_HOST, settings.DASHBOARD_PORT)
