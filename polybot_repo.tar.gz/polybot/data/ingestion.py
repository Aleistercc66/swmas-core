"""Data ingestion: market WS, REST fallback, news, on-chain signals."""

import asyncio
import logging
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Dict, List, Optional

import feedparser
import httpx

from config.settings import settings
from exchange.polymarket import Market, OrderBook, polymarket

logger = logging.getLogger(__name__)


@dataclass
class MarketState:
    """Normalized state snapshot fed to the brain."""
    timestamp: float
    market: Market
    orderbook: Optional[OrderBook] = None
    latest_price: Optional[Decimal] = None
    volume_24h: Decimal = Decimal("0")
    liquidity: Decimal = Decimal("0")
    spread_bps: Optional[int] = None
    # External signals
    news_sentiment_score: Optional[float] = None  # -1.0 to +1.0
    on_chain_signals: Dict[str, Any] = field(default_factory=dict)
    # Derived
    momentum_1h: Optional[Decimal] = None
    momentum_24h: Optional[Decimal] = None


class DataIngestion:
    """Orchestrates market data + external signals into MarketState."""

    def __init__(self):
        self._markets: Dict[str, Market] = {}
        self._orderbooks: Dict[str, OrderBook] = {}
        self._price_history: Dict[str, List[tuple]] = {}  # (timestamp, price)
        self._news_cache: List[Dict[str, Any]] = []
        self._last_news_fetch = 0.0
        self._running = False
        self._tasks: List[asyncio.Task] = []

    # ── Public API ──

    async def refresh_all(self) -> None:
        """Full refresh: markets + orderbooks + external signals."""
        await self._fetch_markets()
        await self._fetch_orderbooks()
        await self._fetch_external_signals()

    async def get_state(self, market_id: str) -> Optional[MarketState]:
        """Return normalized MarketState for a given market."""
        market = self._markets.get(market_id)
        if not market:
            return None

        ob = self._orderbooks.get(market_id)
        latest_price = self._derive_price(ob)
        spread = self._calc_spread_bps(ob)

        # Update price history
        if latest_price is not None:
            self._price_history.setdefault(market_id, []).append(
                (time.time(), latest_price)
            )
            # Keep last 24h (assuming ~1 update/min = 1440 points)
            self._price_history[market_id] = self._price_history[market_id][-2000:]

        mom_1h, mom_24h = self._calc_momentum(market_id)

        return MarketState(
            timestamp=time.time(),
            market=market,
            orderbook=ob,
            latest_price=latest_price,
            volume_24h=market.volume_24h,
            liquidity=market.liquidity,
            spread_bps=spread,
            news_sentiment_score=await self._get_news_sentiment(market.question),
            on_chain_signals=await self._get_on_chain_signals(market_id),
            momentum_1h=mom_1h,
            momentum_24h=mom_24h,
        )

    async def get_all_states(self) -> Dict[str, MarketState]:
        """Return MarketState for all tracked markets."""
        states = {}
        for m_id in self._markets:
            st = await self.get_state(m_id)
            if st:
                states[m_id] = st
        return states

    # ── Internal: Markets ──

    async def _fetch_markets(self) -> None:
        """Fetch active markets from Gamma."""
        try:
            markets = await polymarket.list_markets(active=True, closed=False, limit=200)
            self._markets = {m.id: m for m in markets}
            logger.info("Loaded %d markets", len(self._markets))
        except Exception:
            logger.exception("Failed to fetch markets")

    # ── Internal: Orderbooks ──

    async def _fetch_orderbooks(self) -> None:
        """Fetch orderbooks for tracked markets (top N by liquidity)."""
        top_markets = sorted(
            self._markets.values(), key=lambda m: m.liquidity, reverse=True
        )[:50]

        async def fetch_one(m: Market) -> None:
            try:
                ob = await polymarket.get_orderbook(m.id)
                self._orderbooks[m.id] = ob
            except Exception:
                logger.debug("Orderbook fetch failed for %s", m.id)

        await asyncio.gather(*[fetch_one(m) for m in top_markets])

    # ── Internal: External Signals ──

    async def _fetch_external_signals(self) -> None:
        """Refresh news, sentiment, on-chain signals."""
        await self._fetch_news()

    async def _fetch_news(self) -> None:
        """Fetch news from CryptoPanic, NewsAPI, RSS."""
        now = time.time()
        if now - self._last_news_fetch < 300:  # 5 min cache
            return

        results = []
        async with httpx.AsyncClient(timeout=30.0) as client:
            # CryptoPanic
            if settings.CRYPTOPANIC_API_KEY:
                try:
                    resp = await client.get(
                        "https://cryptopanic.com/api/v1/posts/",
                        params={"auth_token": settings.CRYPTOPANIC_API_KEY, "public": "true"},
                    )
                    if resp.status_code == 200:
                        results.extend(resp.json().get("results", []))
                except Exception:
                    logger.debug("CryptoPanic fetch failed")

            # NewsAPI
            if settings.NEWSAPI_KEY:
                try:
                    resp = await client.get(
                        "https://newsapi.org/v2/everything",
                        params={"q": "prediction market OR Polymarket", "apiKey": settings.NEWSAPI_KEY, "pageSize": 10},
                    )
                    if resp.status_code == 200:
                        results.extend(resp.json().get("articles", []))
                except Exception:
                    logger.debug("NewsAPI fetch failed")

        # RSS feeds
        for feed_url in settings.RSS_FEEDS:
            try:
                parsed = await asyncio.to_thread(feedparser.parse, feed_url)
                results.extend([{"title": e.title, "link": e.link} for e in parsed.entries[:5]])
            except Exception:
                logger.debug("RSS fetch failed: %s", feed_url)

        self._news_cache = results
        self._last_news_fetch = now
        logger.info("Fetched %d news items", len(results))

    async def _get_news_sentiment(self, question: str) -> Optional[float]:
        """Very simple keyword-based sentiment score (-1 to +1)."""
        # This is a placeholder — replace with real NLP if needed
        positive_words = {"surge", "bull", "rally", "breakthrough", "win", "pass", "approved"}
        negative_words = {"crash", "bear", "drop", "scam", "hack", "lose", "fail", "blocked"}

        score = 0.0
        count = 0
        for item in self._news_cache:
            text = (item.get("title") or "") + " " + (item.get("description") or "")
            if any(kw.lower() in text.lower() for kw in question.split()[:3]):
                pos = sum(1 for w in positive_words if w in text.lower())
                neg = sum(1 for w in negative_words if w in text.lower())
                if pos or neg:
                    score += (pos - neg) / max(pos + neg, 1)
                    count += 1

        return score / count if count > 0 else None

    async def _get_on_chain_signals(self, market_id: str) -> Dict[str, Any]:
        """Placeholder for on-chain analysis (Polygonscan, large transfers, etc)."""
        # TODO: Implement via Alchemy/Infura custom queries
        return {"placeholder": True}

    # ── Helpers ──

    def _derive_price(self, ob: Optional[OrderBook]) -> Optional[Decimal]:
        if not ob:
            return None
        best_bid = ob.bids[0].price if ob.bids else None
        best_ask = ob.asks[0].price if ob.asks else None
        if best_bid and best_ask:
            return (best_bid + best_ask) / Decimal("2")
        return best_bid or best_ask

    def _calc_spread_bps(self, ob: Optional[OrderBook]) -> Optional[int]:
        if not ob or not ob.bids or not ob.asks:
            return None
        bid = ob.bids[0].price
        ask = ob.asks[0].price
        if bid <= 0:
            return None
        return int(((ask - bid) / bid) * Decimal("10000"))

    def _calc_momentum(self, market_id: str) -> tuple[Optional[Decimal], Optional[Decimal]]:
        """Return (1h momentum %, 24h momentum %) based on cached prices."""
        history = self._price_history.get(market_id, [])
        if len(history) < 2:
            return None, None

        now_price = history[-1][1]
        now_time = history[-1][0]

        # Find closest to 1h ago
        price_1h = None
        price_24h = None
        for ts, price in reversed(history):
            if price_1h is None and now_time - ts >= 3600:
                price_1h = price
            if price_24h is None and now_time - ts >= 86400:
                price_24h = price
            if price_1h and price_24h:
                break

        mom_1h = ((now_price - price_1h) / price_1h * 100) if price_1h else None
        mom_24h = ((now_price - price_24h) / price_24h * 100) if price_24h else None
        return mom_1h, mom_24h

    # ── Background Tasks ──

    async def _loop_refresh(self) -> None:
        """Periodic full refresh loop."""
        while self._running:
            try:
                await self.refresh_all()
            except Exception:
                logger.exception("Refresh loop error")
            await asyncio.sleep(settings.REST_POLL_INTERVAL)

    async def start(self) -> None:
        """Start background data ingestion."""
        if self._running:
            return
        self._running = True
        self._tasks.append(asyncio.create_task(self._loop_refresh()))
        logger.info("Data ingestion started")

    async def stop(self) -> None:
        """Stop background ingestion."""
        self._running = False
        for t in self._tasks:
            t.cancel()
        self._tasks.clear()
        logger.info("Data ingestion stopped")


# Singleton
ingestion = DataIngestion()
