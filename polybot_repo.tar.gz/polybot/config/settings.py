"""Pydantic Settings for PolyBot."""

import os
from typing import List, Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, validator


class Settings(BaseSettings):
    """All configuration loaded from .env file."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ── Mode ──
    DRY_RUN: bool = Field(default=True, description="If True, no real trades")
    DEBUG: bool = Field(default=False)

    # ── Wallet ──
    PRIVATE_KEY: Optional[str] = Field(default=None, description="0x... Polygon EOA")
    # If PRIVATE_KEY not set, use mnemonic
    MNEMONIC: Optional[str] = Field(default=None)
    DERIVATION_PATH: str = Field(default="m/44'/60'/0'/0/0")

    # ── Chain / RPC ──
    POLYGON_RPC_URL: str = Field(default="https://polygon-rpc.com")
    POLYGON_CHAIN_ID: int = Field(default=137)
    ALCHEMY_API_KEY: Optional[str] = Field(default=None)
    INFURA_API_KEY: Optional[str] = Field(default=None)

    # ── Polymarket ──
    POLYMARKET_API_URL: str = Field(default="https://clob.polymarket.com")
    POLYMARKET_WS_URL: str = Field(default="wss://clob.polymarket.com/ws")
    POLYMARKET_GAMMA_URL: str = Field(default="https://gamma-api.polymarket.com")
    POLYMARKET_API_KEY: Optional[str] = Field(default=None)
    POLYMARKET_API_SECRET: Optional[str] = Field(default=None)
    POLYMARKET_PASSPHRASE: Optional[str] = Field(default=None)

    # ── Collateral ──
    USDC_E_CONTRACT: str = Field(default="0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174")
    MAX_APPROVAL_USDC: float = Field(default=10000.0, description="Bounded USDC approval")

    # ── Risk ──
    MAX_POSITION_PCT: float = Field(default=0.20, description="Max % per market")
    MAX_TOTAL_EXPOSURE_PCT: float = Field(default=0.80, description="Max total exposure")
    DAILY_LOSS_LIMIT_PCT: float = Field(default=0.05, description="Daily loss kill-switch")
    MAX_SLIPPAGE_BPS: int = Field(default=100, description="Max slippage in basis points")
    MAX_GAS_GWEI: int = Field(default=500, description="Gas price cap in Gwei")
    COOLDOWN_AFTER_LOSSES: int = Field(default=3, description="Cooldown after N consecutive losses")
    MARKET_WHITELIST: List[str] = Field(default_factory=list)
    MARKET_BLACKLIST: List[str] = Field(default_factory=list)

    # ── Brain ──
    BRAIN_MODULE: str = Field(default="brain.example", description="Module path for brain")
    BRAIN_CLASS: str = Field(default="ExampleBrain", description="Class name for brain")

    # ── Data / Signals ──
    CRYPTOPANIC_API_KEY: Optional[str] = Field(default=None)
    NEWSAPI_KEY: Optional[str] = Field(default=None)
    RSS_FEEDS: List[str] = Field(default_factory=list)
    WS_RECONNECT_INTERVAL: int = Field(default=5, description="WS reconnect in seconds")
    REST_POLL_INTERVAL: int = Field(default=30, description="REST poll in seconds")

    # ── Scheduler ──
    HEARTBEAT_INTERVAL_MIN: int = Field(default=5)
    PNL_SNAPSHOT_INTERVAL_MIN: int = Field(default=60)
    DATA_REFRESH_INTERVAL_MIN: int = Field(default=15)

    # ── Telegram ──
    TELEGRAM_BOT_TOKEN: Optional[str] = Field(default=None)
    TELEGRAM_CHAT_ID: Optional[str] = Field(default=None)
    TELEGRAM_ADMIN_IDS: List[int] = Field(default_factory=list)

    # ── Dashboard ──
    DASHBOARD_HOST: str = Field(default="0.0.0.0")
    DASHBOARD_PORT: int = Field(default=8080)
    DASHBOARD_AUTH_TOKEN: Optional[str] = Field(default=None)

    # ── Storage ──
    DATABASE_URL: str = Field(default="sqlite:///polybot.db")
    CHROMADB_PATH: Optional[str] = Field(default=None)

    # ── Logging ──
    LOG_LEVEL: str = Field(default="INFO")
    LOG_FILE: str = Field(default="logs/polybot.log")
    LOG_MAX_BYTES: int = Field(default=10_000_000)
    LOG_BACKUP_COUNT: int = Field(default=5)

    @validator("PRIVATE_KEY", pre=True, always=True)
    def _validate_key(cls, v: Optional[str]) -> Optional[str]:
        if v and not v.startswith("0x"):
            raise ValueError("PRIVATE_KEY must start with 0x")
        return v

    @validator("RSS_FEEDS", pre=True, always=True)
    def _split_rss(cls, v):
        if isinstance(v, str):
            return [x.strip() for x in v.split(",") if x.strip()]
        return v or []

    @validator("MARKET_WHITELIST", "MARKET_BLACKLIST", pre=True, always=True)
    def _split_markets(cls, v):
        if isinstance(v, str):
            return [x.strip() for x in v.split(",") if x.strip()]
        return v or []

    @property
    def is_live(self) -> bool:
        """True only when DRY_RUN=False AND user has confirmed live mode."""
        return not self.DRY_RUN

    @property
    def has_wallet(self) -> bool:
        """True if we have either private key or mnemonic."""
        return bool(self.PRIVATE_KEY or self.MNEMONIC)

    @property
    def rpc_url(self) -> str:
        """Return best available RPC URL."""
        if self.ALCHEMY_API_KEY:
            return f"https://polygon-mainnet.g.alchemy.com/v2/{self.ALCHEMY_API_KEY}"
        if self.INFURA_API_KEY:
            return f"https://polygon-mainnet.infura.io/v3/{self.INFURA_API_KEY}"
        return self.POLYGON_RPC_URL


# Global singleton — imported by all modules
settings = Settings()
