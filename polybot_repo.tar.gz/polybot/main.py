"""PolyBot main entrypoint."""

import asyncio
import logging
import os
import signal
import sys
from pathlib import Path

# Ensure logs dir exists
os.makedirs("logs", exist_ok=True)

from config.settings import settings
from storage.db import init_db
from observability.dashboard import start_dashboard
from observability.telegram_bot import telegram
from scheduler.orchestrator import orchestrator

# ── Logging ──

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.handlers.RotatingFileHandler(
            settings.LOG_FILE,
            maxBytes=settings.LOG_MAX_BYTES,
            backupCount=settings.LOG_BACKUP_COUNT,
        ),
    ],
)
logger = logging.getLogger("main")


async def main():
    """Bootstrap and run the bot."""
    logger.info("=" * 60)
    logger.info("  PolyBot v1.0 — Polymarket AI Trading Bot")
    logger.info("=" * 60)
    logger.info("DRY_RUN=%s | BRAIN=%s | WALLET=%s", settings.DRY_RUN, settings.BRAIN_MODULE, settings.has_wallet)

    # 1. Init database
    init_db()

    # 2. Start dashboard
    start_dashboard()

    # 3. Start Telegram bot
    await telegram.start()

    # 4. Start orchestrator (scheduler + brain cycles)
    await orchestrator.start()

    # 5. Run forever
    logger.info("Bot running. Press Ctrl+C to stop.")
    try:
        while True:
            await asyncio.sleep(1)
    except asyncio.CancelledError:
        logger.info("Shutdown signal received...")
    finally:
        await orchestrator.stop()
        await telegram.stop()
        logger.info("PolyBot stopped cleanly. Goodbye!")


def handle_signal(sig, frame):
    logger.info("Signal %d received — initiating shutdown", sig)
    sys.exit(0)


if __name__ == "__main__":
    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)
    asyncio.run(main())
