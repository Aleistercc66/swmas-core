"""Scheduler orchestrator: APScheduler + asyncio loops + heartbeat."""

import asyncio
import json
import logging
import time
from decimal import Decimal
from typing import Any, Dict

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger

from config.settings import settings
from brain.interface import BrainInterface, Portfolio
from brain.example import ExampleBrain
from data.ingestion import ingestion, MarketState
from exchange.polymarket import polymarket
from wallet.manager import wallet
from risk.manager import risk
from execution.executor import executor
from observability.telegram_bot import telegram
from observability.dashboard import dashboard_state

logger = logging.getLogger(__name__)


class Orchestrator:
    """Central scheduler tying all modules together."""

    def __init__(self):
        self.scheduler = AsyncIOScheduler()
        self._running = False
        self._brain: BrainInterface = self._load_brain()
        self._heartbeats: list = []

    # ── Brain Loading ──

    def _load_brain(self) -> BrainInterface:
        """Dynamic brain loading from settings."""
        module_path = settings.BRAIN_MODULE
        class_name = settings.BRAIN_CLASS
        try:
            import importlib
            mod = importlib.import_module(module_path)
            cls = getattr(mod, class_name)
            instance = cls()
            instance.on_init()
            logger.info("Brain loaded: %s.%s", module_path, class_name)
            return instance
        except Exception as e:
            logger.error("Failed to load brain %s.%s: %s — falling back to ExampleBrain", module_path, class_name, e)
            brain = ExampleBrain()
            brain.on_init()
            return brain

    # ── Core Loop ──

    async def _brain_cycle(self) -> None:
        """One decision cycle: fetch state → brain decides → risk check → execute."""
        try:
            # 1. Build portfolio snapshot
            balance = await wallet.get_usdc_balance()
            # TODO: Load positions from storage
            portfolio = Portfolio(
                total_usdc=balance,
                available_usdc=balance,
                positions={},
                open_orders=[],
                daily_pnl=Decimal("0"),
                daily_loss_pct=Decimal("0"),
            )

            # 2. Get all market states
            states = await ingestion.get_all_states()
            if not states:
                logger.warning("No market states available — skipping cycle")
                return

            # 3. Brain decides
            decisions = self._brain.decide(states, portfolio)
            if not decisions:
                logger.debug("Brain returned no decisions")
                return

            logger.info("Brain returned %d decisions", len(decisions))
            dashboard_state["last_decisions"] = [
                {"market_id": d.market_id, "side": d.side, "size": float(d.size), "confidence": d.confidence}
                for d in decisions
            ]

            # 4. Execute each decision
            for decision in decisions:
                order = await executor.execute(decision)
                if order.status.name == "FILLED":
                    await telegram.notify_trade(decision)
                elif order.status.name == "FAILED":
                    await telegram.notify_error(f"Order failed: {order.error}")

        except Exception:
            logger.exception("Brain cycle error")
            await telegram.notify_error("Brain cycle crashed — check logs!")

    # ── Scheduled Jobs ──

    async def _heartbeat(self) -> None:
        """Heartbeat: check health, log status, ping Telegram."""
        try:
            w_health = await wallet.health()
            p_health = await polymarket.health()
            r_state = risk.to_dict()

            hb = {
                "time": time.time(),
                "wallet": w_health,
                "exchange": p_health,
                "risk": r_state,
                "dry_run": settings.DRY_RUN,
            }
            self._heartbeats.append(hb)
            self._heartbeats = self._heartbeats[-100:]  # Keep last 100
            dashboard_state["heartbeats"] = self._heartbeats

            # Write to file
            with open("heartbeat.json", "w") as f:
                json.dump(hb, f, default=str)

            logger.info("Heartbeat | wallet=%s exchange=%s risk=%s", w_health, p_health, r_state)

            if not w_health.get("connected"):
                await telegram.notify_error("⚠️ Wallet RPC disconnected!")

        except Exception:
            logger.exception("Heartbeat failed")

    async def _pnl_snapshot(self) -> None:
        """Periodic P&L snapshot."""
        try:
            balance = await wallet.get_usdc_balance()
            # TODO: Calculate real P&L from storage
            snapshot = {"time": time.time(), "balance": float(balance), "daily_pnl": 0.0}
            dashboard_state["pnl_history"].append(snapshot)
            logger.info("P&L snapshot: balance=%.2f USDC", balance)
        except Exception:
            logger.exception("P&L snapshot failed")

    async def _daily_summary(self) -> None:
        """Daily P&L summary to Telegram."""
        try:
            r_state = risk.to_dict()
            msg = (
                f"📊 Daily Summary\n"
                f"Daily P&L: {r_state['daily_pnl']:.2f} USDC\n"
                f"Daily Loss %: {r_state['daily_loss_pct']:.2%}\n"
                f"Kill Switch: {'🚨 ON' if r_state['kill_switch'] else '✅ OFF'}\n"
                f"Dry Run: {'🧪 YES' if settings.DRY_RUN else '🔴 LIVE'}"
            )
            await telegram.send_message(msg)
        except Exception:
            logger.exception("Daily summary failed")

    async def _data_refresh(self) -> None:
        """Periodic full data refresh."""
        try:
            await ingestion.refresh_all()
        except Exception:
            logger.exception("Data refresh failed")

    # ── Lifecycle ──

    async def start(self) -> None:
        """Start all background tasks and scheduler."""
        if self._running:
            return
        self._running = True

        # Start ingestion
        await ingestion.start()
        await polymarket.start_ws()

        # Schedule jobs
        self.scheduler.add_job(
            self._brain_cycle,
            trigger=IntervalTrigger(seconds=30),
            id="brain_cycle",
            replace_existing=True,
        )
        self.scheduler.add_job(
            self._heartbeat,
            trigger=IntervalTrigger(minutes=settings.HEARTBEAT_INTERVAL_MIN),
            id="heartbeat",
            replace_existing=True,
        )
        self.scheduler.add_job(
            self._pnl_snapshot,
            trigger=IntervalTrigger(minutes=settings.PNL_SNAPSHOT_INTERVAL_MIN),
            id="pnl_snapshot",
            replace_existing=True,
        )
        self.scheduler.add_job(
            self._data_refresh,
            trigger=IntervalTrigger(minutes=settings.DATA_REFRESH_INTERVAL_MIN),
            id="data_refresh",
            replace_existing=True,
        )
        self.scheduler.add_job(
            self._daily_summary,
            trigger=IntervalTrigger(hours=24),
            id="daily_summary",
            replace_existing=True,
        )

        self.scheduler.start()
        logger.info("🚀 Orchestrator started | brain=%s dry_run=%s", settings.BRAIN_MODULE, settings.DRY_RUN)
        await telegram.send_message("🚀 PolyBot started!\nDry Run: {}".format("YES 🧪" if settings.DRY_RUN else "NO 🔴 LIVE"))

    async def stop(self) -> None:
        """Graceful shutdown."""
        self._running = False
        self.scheduler.shutdown(wait=False)
        await ingestion.stop()
        await polymarket.stop_ws()
        self._brain.on_shutdown()
        logger.info("Orchestrator stopped")
        await telegram.send_message("🛑 PolyBot stopped")

    # ── Remote Commands ──

    async def command_pause(self) -> str:
        await risk.pause()
        return "Trading paused ⏸️"

    async def command_resume(self) -> str:
        await risk.resume()
        return "Trading resumed ▶️"

    async def command_killall(self) -> str:
        await executor.emergency_stop()
        return "🚨 EMERGENCY STOP — all orders cancelled, kill switch ON"

    async def command_status(self) -> str:
        r = risk.to_dict()
        bal = await wallet.get_usdc_balance()
        return (
            f"Status:\n"
            f"  Dry Run: {settings.DRY_RUN}\n"
            f"  Kill Switch: {r['kill_switch']}\n"
            f"  Paused: {r['paused_until'] is not None}\n"
            f"  Daily P&L: {r['daily_pnl']:.2f}\n"
            f"  Consecutive Losses: {r['consecutive_losses']}\n"
            f"  USDC Balance: {bal:.2f}"
        )

    async def command_positions(self) -> str:
        return "Positions: TODO (load from storage)"

    async def command_pnl(self) -> str:
        r = risk.to_dict()
        return f"Daily P&L: {r['daily_pnl']:.2f} USDC ({r['daily_loss_pct']:.2%})"

    async def confirm_live(self) -> str:
        if not settings.DRY_RUN:
            return "Already live! 🔴"
        # This would require a restart with DRY_RUN=false
        return "Set DRY_RUN=false in .env and restart to go live. ⚠️ DANGER!"


# Singleton
orchestrator = Orchestrator()
