"""SQLAlchemy models + database init."""

import logging
from datetime import datetime
from decimal import Decimal
from typing import Optional

from sqlalchemy import create_engine, Column, String, Float, DateTime, Integer, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker

from config.settings import settings

logger = logging.getLogger(__name__)
Base = declarative_base()


class TradeRecord(Base):
    """Log of all executed trades."""
    __tablename__ = "trades"

    id = Column(String, primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    market_id = Column(String, nullable=False)
    outcome = Column(String, nullable=False)
    side = Column(String, nullable=False)
    size = Column(Float, nullable=False)
    price = Column(Float)
    status = Column(String, nullable=False)
    pnl = Column(Float, default=0.0)
    tx_hash = Column(String)
    error = Column(String)
    dry_run = Column(Boolean, default=True)


class PositionRecord(Base):
    """Current positions snapshot."""
    __tablename__ = "positions"

    market_id = Column(String, primary_key=True)
    outcome = Column(String, primary_key=True)
    size = Column(Float, default=0.0)
    avg_price = Column(Float)
    open_time = Column(DateTime, default=datetime.utcnow)
    unrealized_pnl = Column(Float, default=0.0)


class PnLSnapshot(Base):
    """Periodic P&L snapshots."""
    __tablename__ = "pnl_snapshots"

    id = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    balance = Column(Float)
    daily_pnl = Column(Float)
    total_pnl = Column(Float)


class SystemLog(Base):
    """Structured log entries."""
    __tablename__ = "system_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    level = Column(String)
    module = Column(String)
    message = Column(String)


# ── Engine / Session ──

engine = create_engine(
    settings.DATABASE_URL,
    echo=settings.DEBUG,
    connect_args={"check_same_thread": False} if "sqlite" in settings.DATABASE_URL else {},
)
SessionLocal = sessionmaker(bind=engine)


def init_db() -> None:
    """Create all tables."""
    Base.metadata.create_all(bind=engine)
    logger.info("Database initialized: %s", settings.DATABASE_URL)


def get_db():
    """Yield a DB session (use in context manager)."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
