"""Polymarket CLOB + Gamma API integration.

Provides async wrappers for:
- Market discovery (Gamma API)
- Orderbook reads (CLOB REST + WS)
- Order placement / cancellation (CLOB REST, EIP-712 signed)
"""
import asyncio
import json
from typing import Dict, List, Optional, Any

import httpx
import websockets
from web3 import Web3

from config.settings import settings
from wallet.manager import WalletManager


# Polymarket CLOB endpoint paths
CLOB_HOST = settings.polymarket_api_url
GAMMA_HOST = settings.polymarket_gamma_url
WS_URL = settings.polymarket_ws_url


class PolymarketClient:
    """Async client for Polymarket CLOB and Gamma APIs."""

    def __init__(self, wallet: WalletManager):
        self.wallet = wallet
        self.http = httpx.AsyncClient(
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            timeout=30.0,
        )
        self.ws: Optional[websockets.WebSocketClientProtocol] = None
        self.subscribed_markets: set = set()
        self._last_book: Dict[str, dict] = {}  # market_id -> orderbook snapshot

    # --- Gamma API: Market Discovery ---

    async def get_active_markets(self, limit: int = 100) -> List[dict]:
        """Fetch open markets from Gamma API."""
        url = f"{GAMMA_HOST}/markets"
        params = {"active": "true", "closed": "false", "limit": limit}
        resp = await self.http.get(url, params=params)
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("markets", [])

    async def get_market(self, market_id: str) -> Optional[dict]:
        """Fetch single market metadata."""
        url = f"{GAMMA_HOST}/markets/{market_id}"
        resp = await self.http.get(url)
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()

    # --- CLOB REST: Orderbook ---

    async def get_orderbook(self, market_id: str, outcome: str = "YES") -> dict:
        """Fetch current orderbook for a market outcome."""
        token_id = await self._get_token_id(market_id, outcome)
        url = f"{CLOB_HOST}/book/{token_id}"
        resp = await self.http.get(url)
        resp.raise_for_status()
        book = resp.json()
        self._last_book[market_id] = book
        return book

    async def get_price(self, market_id: str, outcome: str = "YES", side: str = "BUY") -> float:
        """Get best price for a side (best bid for BUY, best ask for SELL)."""
        book = await self.get_orderbook(market_id, outcome)
        if side.upper() == "BUY":
            bids = book.get("bids", [])
            return float(bids[0]["price"]) if bids else 0.0
        else:
            asks = book.get("asks", [])
            return float(asks[0]["price"]) if asks else 1.0

    # --- CLOB: Orders ---

    async def place_order(
        self,
        market_id: str,
        side: str,  # BUY or SELL
        outcome: str,  # YES or NO
        size: float,
        price: float,
        slippage_bps: int = 100,
    ) -> dict:
        """Place an order on the CLOB.

        Signs the order via EIP-712 using the wallet's EOA key.
        """
        if settings.dry_run:
            print(f"[DRY RUN] Would place {side} {size} {outcome} @ {price}")
            return {"dry_run": True, "status": "submitted"}

        token_id = await self._get_token_id(market_id, outcome)

        # Build CLOB order payload (simplified — real py-clob-client handles the full flow)
        order_payload = {
            "order": {
                "token_id": token_id,
                "side": side.upper(),
                "type": "LIMIT",
                "price": str(price),
                "size": str(size),
                "fee_rate_bps": "0",
                "nonce": 0,  # real client manages nonce
                "expiration": "0",
                "taker": "0x0000000000000000000000000000000000000000",
            }
        }

        # Sign the order
        # Note: Real py-clob-client handles full EIP-712 domain + types
        # This is a scaffold — user wires in py-clob-client's OrderClient for production
        order_hash = self._hash_order(order_payload["order"])
        signature = self.wallet.sign_message(order_hash)
        order_payload["signature"] = signature
        order_payload["owner"] = self.wallet.address

        url = f"{CLOB_HOST}/order"
        resp = await self.http.post(url, json=order_payload)
        resp.raise_for_status()
        return resp.json()

    async def cancel_order(self, order_id: str) -> dict:
        """Cancel an open order."""
        if settings.dry_run:
            print(f"[DRY RUN] Would cancel order {order_id}")
            return {"dry_run": True, "status": "cancelled"}

        url = f"{CLOB_HOST}/order/{order_id}"
        resp = await self.http.delete(url)
        resp.raise_for_status()
        return resp.json()

    async def cancel_all(self) -> dict:
        """Cancel all open orders."""
        if settings.dry_run:
            print("[DRY RUN] Would cancel all orders")
            return {"dry_run": True, "status": "cancelled_all"}

        url = f"{CLOB_HOST}/orders"
        resp = await self.http.delete(url)
        resp.raise_for_status()
        return resp.json()

    # --- WebSocket ---

    async def ws_connect(self):
        """Connect to Polymarket WS for real-time orderbook updates."""
        self.ws = await websockets.connect(WS_URL)
        asyncio.create_task(self._ws_loop())

    async def ws_subscribe(self, market_ids: List[str]):
        """Subscribe to market channels."""
        if not self.ws:
            await self.ws_connect()
        for mid in market_ids:
            msg = {"type": "subscribe", "channel": "orderbook", "market": mid}
            await self.ws.send(json.dumps(msg))
            self.subscribed_markets.add(mid)

    async def _ws_loop(self):
        """Background task: read WS messages and update local cache."""
        try:
            async for message in self.ws:
                data = json.loads(message)
                # Update local orderbook cache
                mid = data.get("market")
                if mid:
                    self._last_book[mid] = data
        except websockets.ConnectionClosed:
            print("[Polymarket WS] Connection closed — will reconnect via fallback")
        except Exception as e:
            print(f"[Polymarket WS] Error: {e}")

    # --- Helpers ---

    async def _get_token_id(self, market_id: str, outcome: str) -> str:
        """Fetch the ERC-1155 token_id for a market outcome."""
        market = await self.get_market(market_id)
        if not market:
            raise ValueError(f"Market {market_id} not found")
        tokens = market.get("tokens", [])
        for t in tokens:
            if t.get("outcome", "").upper() == outcome.upper():
                return t["token_id"]
        raise ValueError(f"Outcome {outcome} not found for market {market_id}")

    def _hash_order(self, order_dict: dict) -> str:
        """Stub: returns a deterministic string hash of order dict.
        Real py-clob-client uses EIP-712 typed data hashing."""
        return Web3.keccak(text=json.dumps(order_dict, sort_keys=True)).hex()

    async def close(self):
        await self.http.aclose()
        if self.ws:
            await self.ws.close()
