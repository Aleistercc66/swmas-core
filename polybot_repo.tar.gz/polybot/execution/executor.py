"""Execution engine: order lifecycle, retries, gas, pre-flight checks."""

import asyncio
import logging
from decimal import Decimal
from typing import Any, Dict, List, Optional
from dataclasses import dataclass
from enum import Enum

from config.settings import settings
from exchange.polymarket import polymarket
from wallet.manager import wallet
from risk.manager import risk
from brain.interface import TradeDecision

logger = logging.getLogger(__name__)


class OrderStatus(Enum):
    CREATED = "created"
    SUBMITTED = "submitted"
    FILLED = "filled"
    PARTIALLY_FILLED = "partially_filled"
    CANCELLED = "cancelled"
    FAILED = "failed"


@dataclass
class Order:
    id: Optional[str]
    status: OrderStatus
    decision: TradeDecision
    tx_hash: Optional[str] = None
    filled_size: Decimal = Decimal("0")
    error: Optional[str] = None


class ExecutionEngine:
    """Manages order lifecycle from decision to fill/cancel."""

    def __init__(self):
        self._orders: Dict[str, Order] = {}
        self._lock = asyncio.Lock()
        self._dry_run = settings.DRY_RUN

    # ── Pre-flight Checks ──

    async def _preflight(self, decision: TradeDecision) -> Optional[str]:
        """Return error string if pre-flight fails, else None."""
        # 1. Wallet balance
        balance = await wallet.get_usdc_balance()
        if balance < decision.size:
            return f"Insufficient USDC: {balance} < {decision.size}"

        # 2. Gas cap
        try:
            gas_price = wallet.w3.eth.gas_price
            max_gas_wei = wallet.w3.to_wei(settings.MAX_GAS_GWEI, "gwei")
            if gas_price > max_gas_wei:
                return f"Gas {wallet.w3.from_wei(gas_price, 'gwei')} > max {settings.MAX_GAS_GWEI} Gwei"
        except Exception as e:
            return f"Gas check failed: {e}"

        # 3. Market liquidity (from cached data)
        # TODO: Implement real liquidity check via orderbook depth

        # 4. Slippage check
        # TODO: Implement slippage estimation

        # 5. USDC allowance check
        # Polymarket CLOB spender address — verify before mainnet!
        CLOB_SPENDER = "0x4bFb41d5B3570DeFd03C39a9A4D8dEeBd28Fb74a"  # Verify on docs
        allowance = await wallet.get_allowance(CLOB_SPENDER)
        if allowance < decision.size:
            logger.info("USDC allowance %.2f < %.2f — approving", allowance, decision.size)
            try:
                await wallet.approve_usdc(CLOB_SPENDER, amount=Decimal(str(settings.MAX_APPROVAL_USDC)))
            except Exception as e:
                return f"Approval failed: {e}"

        return None

    # ── Order Execution ──

    async def execute(self, decision: TradeDecision) -> Order:
        """Execute a single trade decision."""
        order_id = f"pending_{id(decision)}"
        order = Order(id=None, status=OrderStatus.CREATED, decision=decision)

        async with self._lock:
            self._orders[order_id] = order

        # Pre-flight
        err = await self._preflight(decision)
        if err:
            order.status = OrderStatus.FAILED
            order.error = err
            logger.error("Pre-flight failed: %s", err)
            return order

        # Risk check
        from brain.interface import Portfolio
        portfolio = Portfolio(
            total_usdc=await wallet.get_usdc_balance(),
            available_usdc=await wallet.get_usdc_balance(),
            positions={},
            open_orders=[],
            daily_pnl=Decimal("0"),
        )
        if not await risk.check_trade(decision, portfolio):
            order.status = OrderStatus.FAILED
            order.error = "Risk check failed"
            return order

        if self._dry_run:
            logger.info("[DRY RUN] Would execute: %s", decision)
            order.status = OrderStatus.FILLED  # Simulate
            order.filled_size = decision.size
            return order

        # Live execution
        try:
            order.status = OrderStatus.SUBMITTED
            # Build Polymarket CLOB order payload
            # This requires EIP-712 signing via wallet
            payload = await self._build_order_payload(decision)
            result = await polymarket.place_order(payload)
            order.id = result.get("orderID") or result.get("id")
            order.status = OrderStatus.FILLED if result.get("status") == "matched" else OrderStatus.SUBMITTED
            logger.info("Order submitted: %s", order.id)
        except Exception as e:
            order.status = OrderStatus.FAILED
            order.error = str(e)
            logger.exception("Order execution failed")

        return order

    async def _build_order_payload(self, decision: TradeDecision) -> Dict[str, Any]:
        """Build and sign order payload for Polymarket CLOB."""
        # Placeholder — real implementation depends on py-clob-client schema
        # See: https://github.com/Polymarket/py-clob-client
        order_data = {
            "market": decision.market_id,
            "side": decision.side,
            "outcome": decision.outcome,
            "size": float(decision.size),
            "price": float(decision.price) if decision.price else None,
            "type": decision.order_type,
            "timeInForce": decision.time_in_force,
        }
        # Sign with wallet
        signature = wallet.sign_order(order_data)
        order_data["signature"] = signature
        order_data["address"] = wallet.address
        return order_data

    # ── Order Management ──

    async def cancel(self, order_id: str) -> bool:
        """Cancel an open order."""
        try:
            await polymarket.cancel_order(order_id)
            return True
        except Exception as e:
            logger.error("Cancel failed: %s", e)
            return False

    async def cancel_all(self) -> int:
        """Cancel all open orders. Returns count cancelled."""
        try:
            orders = await polymarket.list_orders()
            cancelled = 0
            for o in orders:
                oid = o.get("id")
                if oid:
                    if await self.cancel(oid):
                        cancelled += 1
            return cancelled
        except Exception:
            logger.exception("Cancel all failed")
            return 0

    # ── Status ──

    def get_orders(self) -> List[Order]:
        return list(self._orders.values())

    def get_order(self, order_id: str) -> Optional[Order]:
        return self._orders.get(order_id)

    # ── Kill Switch ──

    async def emergency_stop(self) -> None:
        """Cancel all orders + pause."""
        logger.critical("🚨 EMERGENCY STOP — cancelling all orders!")
        count = await self.cancel_all()
        logger.critical("Cancelled %d orders", count)
        await risk.trigger_kill_switch("Emergency stop invoked")


# Singleton
executor = ExecutionEngine()
