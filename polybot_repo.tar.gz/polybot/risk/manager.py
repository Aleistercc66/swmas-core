"""Risk manager: sizing, exposure limits, kill-switch, cooldown."""

import asyncio
import logging
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict, List, Optional, Set

from brain.interface import Portfolio, TradeDecision
from config.settings import settings

logger = logging.getLogger(__name__)


@dataclass
class RiskState:
    """Mutable risk tracking state."""
    daily_pnl: Decimal = Decimal("0")
    daily_loss_pct: Decimal = Decimal("0")
    consecutive_losses: int = 0
    kill_switch: bool = False
    paused_until: Optional[float] = None
    last_trade_time: Dict[str, float] = field(default_factory=dict)
    positions_exposure: Dict[str, Decimal] = field(default_factory=dict)


class RiskManager:
    """Enforce all risk rules before execution."""

    def __init__(self):
        self.state = RiskState()
        self._lock = asyncio.Lock()
        self._day_start = time.time()

    # ── Core: Validate Trade ──

    async def check_trade(self, decision: TradeDecision, portfolio: Portfolio) -> bool:
        """Return True if trade passes ALL risk checks."""
        async with self._lock:
            if self.state.kill_switch:
                logger.warning("Trade REJECTED — kill switch active")
                return False

            if self.state.paused_until and time.time() < self.state.paused_until:
                logger.warning("Trade REJECTED — paused until %.0f", self.state.paused_until)
                return False

            # Daily loss limit
            if portfolio.daily_loss_pct is not None:
                if abs(portfolio.daily_loss_pct) >= Decimal(str(settings.DAILY_LOSS_LIMIT_PCT)):
                    logger.warning("Trade REJECTED — daily loss limit hit: %.2f%%", portfolio.daily_loss_pct)
                    await self.trigger_kill_switch("Daily loss limit exceeded")
                    return False

            # Market whitelist/blacklist
            if settings.MARKET_WHITELIST and decision.market_id not in settings.MARKET_WHITELIST:
                logger.warning("Trade REJECTED — market not in whitelist")
                return False
            if decision.market_id in settings.MARKET_BLACKLIST:
                logger.warning("Trade REJECTED — market in blacklist")
                return False

            # Position sizing
            position_size_pct = (decision.size / portfolio.total_usdc) if portfolio.total_usdc > 0 else Decimal("0")
            if position_size_pct > Decimal(str(settings.MAX_POSITION_PCT)):
                logger.warning(
                    "Trade REJECTED — position size %.2f%% > max %.2f%%",
                    position_size_pct * 100, float(settings.MAX_POSITION_PCT) * 100,
                )
                return False

            # Total exposure
            current_exposure = sum(self.state.positions_exposure.values(), Decimal("0"))
            new_exposure = current_exposure + decision.size
            if new_exposure > portfolio.total_usdc * Decimal(str(settings.MAX_TOTAL_EXPOSURE_PCT)):
                logger.warning("Trade REJECTED — total exposure would exceed limit")
                return False

            # Confidence minimum
            if decision.confidence < 60:
                logger.warning("Trade REJECTED — confidence %d/100 < 60", decision.confidence)
                return False

            # Cooldown after consecutive losses
            if self.state.consecutive_losses >= settings.COOLDOWN_AFTER_LOSSES:
                logger.warning("Trade REJECTED — cooldown after %d consecutive losses", self.state.consecutive_losses)
                self.state.paused_until = time.time() + 3600  # 1 hour cooldown
                return False

            return True

    # ── Portfolio Helpers ──

    async def update_exposure(self, market_id: str, size_delta: Decimal) -> None:
        async with self._lock:
            current = self.state.positions_exposure.get(market_id, Decimal("0"))
            new = current + size_delta
            if new <= 0:
                self.state.positions_exposure.pop(market_id, None)
            else:
                self.state.positions_exposure[market_id] = new

    async def update_pnl(self, trade_pnl: Decimal) -> None:
        async with self._lock:
            self.state.daily_pnl += trade_pnl
            if self.state.daily_pnl == 0:
                self.state.daily_loss_pct = Decimal("0")
            else:
                # Assume reference capital is tracked externally
                pass

            if trade_pnl < 0:
                self.state.consecutive_losses += 1
            else:
                self.state.consecutive_losses = 0

    # ── Kill Switch ──

    async def trigger_kill_switch(self, reason: str) -> None:
        async with self._lock:
            self.state.kill_switch = True
            logger.critical("🚨 KILL SWITCH ACTIVATED: %s", reason)

    async def reset_kill_switch(self) -> None:
        async with self._lock:
            self.state.kill_switch = False
            self.state.paused_until = None
            self.state.consecutive_losses = 0
            logger.info("Kill switch reset — trading resumed")

    async def pause(self, duration_sec: int = 3600) -> None:
        async with self._lock:
            self.state.paused_until = time.time() + duration_sec
            logger.info("Trading paused for %d seconds", duration_sec)

    async def resume(self) -> None:
        async with self._lock:
            self.state.paused_until = None
            logger.info("Trading resumed")

    # ── Daily Reset ──

    async def maybe_reset_daily(self, portfolio_total: Decimal) -> None:
        """Reset daily stats if new day."""
        now = time.time()
        if now - self._day_start >= 86400:
            async with self._lock:
                self.state.daily_pnl = Decimal("0")
                self.state.daily_loss_pct = Decimal("0")
                self._day_start = now
                logger.info("Daily risk stats reset")

    # ── State Dump ──

    def to_dict(self) -> dict:
        return {
            "daily_pnl": float(self.state.daily_pnl),
            "daily_loss_pct": float(self.state.daily_loss_pct),
            "consecutive_losses": self.state.consecutive_losses,
            "kill_switch": self.state.kill_switch,
            "paused_until": self.state.paused_until,
            "total_exposure": float(sum(self.state.positions_exposure.values(), Decimal("0"))),
        }


# Singleton
risk = RiskManager()
