"""Wallet management — key storage, EIP-712 signing, USDC allowance.

Security rules:
- Private key loaded ONLY from env or OS keychain.
- Never logged, never serialized, never exposed via API.
- Approval is bounded (MAX_APPROVAL_USDC), never unlimited.
"""
import os
from typing import Optional

from eth_account import Account
from eth_account.messages import encode_defunct
from web3 import Web3
from web3.types import TxParams, Wei

from config.settings import settings

# Minimal ERC-20 ABI for USDC.e
ERC20_ABI = [
    {"constant": True, "inputs": [], "name": "decimals", "outputs": [{"name": "", "type": "uint8"}], "type": "function"},
    {"constant": True, "inputs": [{"name": "_owner", "type": "address"}, {"name": "_spender", "type": "address"}], "name": "allowance", "outputs": [{"name": "", "type": "uint256"}], "type": "function"},
    {"constant": False, "inputs": [{"name": "_spender", "type": "address"}, {"name": "_value", "type": "uint256"}], "name": "approve", "outputs": [{"name": "", "type": "bool"}], "type": "function"},
    {"constant": True, "inputs": [{"name": "_owner", "type": "address"}], "name": "balanceOf", "outputs": [{"name": "", "type": "uint256"}], "type": "function"},
]


class WalletManager:
    """Manages Polygon EOA wallet, signing, and USDC operations."""

    def __init__(self, w3: Optional[Web3] = None):
        self.w3 = w3 or Web3(Web3.HTTPProvider(settings.rpc_url))
        self.account: Optional[Account] = None
        self.address: Optional[str] = None
        self._load_key()
        self.usdc = self.w3.eth.contract(
            address=Web3.to_checksum_address(settings.usdc_contract),
            abi=ERC20_ABI,
        )

    def _load_key(self):
        """Load private key securely."""
        key = settings.polygon_private_key
        if not key:
            # Fallback: try OS keychain or prompt (not implemented — keep it simple)
            raise RuntimeError("POLYGON_PRIVATE_KEY not set in environment.")
        if key.startswith("0x"):
            key = key[2:]
        self.account = Account.from_key(key)
        self.address = self.account.address

    # --- Balance & Allowance ---

    async def get_usdc_balance(self) -> float:
        """Return USDC.e balance as human-readable float."""
        raw = self.usdc.functions.balanceOf(self.address).call()
        decimals = self.usdc.functions.decimals().call()
        return raw / (10 ** decimals)

    async def get_allowance(self, spender: str) -> float:
        """Return USDC allowance for spender."""
        spender = Web3.to_checksum_address(spender)
        raw = self.usdc.functions.allowance(self.address, spender).call()
        decimals = self.usdc.functions.decimals().call()
        return raw / (10 ** decimals)

    async def ensure_allowance(self, spender: str, min_amount: float) -> Optional[str]:
        """Approve spender up to MAX_APPROVAL_USDC if below min_amount.

        Returns tx_hash if approval sent, None if already sufficient.
        """
        current = await self.get_allowance(spender)
        if current >= min_amount:
            return None

        if settings.dry_run:
            print(f"[DRY RUN] Would approve {spender} for {settings.max_approval_usdc} USDC")
            return "dry-run-approval"

        spender = Web3.to_checksum_address(spender)
        decimals = self.usdc.functions.decimals().call()
        amount = int(settings.max_approval_usdc * (10 ** decimals))

        tx = self.usdc.functions.approve(spender, amount).build_transaction({
            "from": self.address,
            "nonce": self.w3.eth.get_transaction_count(self.address),
            "gas": 100_000,
            "maxFeePerGas": self.w3.to_wei(settings.max_gas_gwei, "gwei"),
            "maxPriorityFeePerGas": self.w3.to_wei("30", "gwei"),
            "chainId": 137,
        })
        signed = self.account.sign_transaction(tx)
        tx_hash = self.w3.eth.send_raw_transaction(signed.rawTransaction)
        return tx_hash.hex()

    # --- Signing ---

    def sign_message(self, message: str) -> str:
        """Sign a raw message string with the EOA key."""
        msghash = encode_defunct(text=message)
        signed = self.account.sign_message(msghash)
        return signed.signature.hex()

    def sign_eip712(self, domain, types, value) -> str:
        """Sign an EIP-712 typed data structure.

        Args match the standard: domain, types dict, value dict.
        """
        from eth_account.messages import encode_typed_data
        full_message = encode_typed_data(domain, types, value)
        signed = self.account.sign_message(full_message)
        return signed.signature.hex()

    # --- Generic TX helper ---

    async def send_transaction(self, tx_dict: TxParams) -> str:
        """Sign and send a generic transaction dict. Returns tx_hash hex."""
        if settings.dry_run:
            print(f"[DRY RUN] Would send tx: {tx_dict}")
            return "dry-run-tx"

        tx_dict["nonce"] = self.w3.eth.get_transaction_count(self.address)
        if "maxFeePerGas" not in tx_dict:
            tx_dict["maxFeePerGas"] = self.w3.to_wei(settings.max_gas_gwei, "gwei")
        if "maxPriorityFeePerGas" not in tx_dict:
            tx_dict["maxPriorityFeePerGas"] = self.w3.to_wei("30", "gwei")
        if "chainId" not in tx_dict:
            tx_dict["chainId"] = 137

        signed = self.account.sign_transaction(tx_dict)
        tx_hash = self.w3.eth.send_raw_transaction(signed.rawTransaction)
        return tx_hash.hex()
