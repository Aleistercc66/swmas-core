# PolyBot

> Autonomous AI Trading Bot for Polymarket Prediction Markets on Polygon

## 5-Line Executive Summary

- **What:** Production-grade, modular Python bot that reads Polymarket CLOB data, runs user-defined strategy logic ("brain"), and executes trades on-chain via a Polygon EOA wallet.
- **Safety:** `DRY_RUN=true` by default. First live trade requires manual `/confirm_live` Telegram command. Kill-switch, daily loss limits, bounded USDC approvals.
- **Architecture:** 10 modules (config, wallet, exchange, data, brain, risk, execution, scheduler, observability, storage) — each swappable and independently testable.
- **Observability:** Structured JSON logs, Telegram real-time alerts, FastAPI dashboard at `:8080`, heartbeat file for systemd/Docker healthchecks.
- **Target:** Windows 16GB RAM / Linux / Docker. Zero GPU required. All free/OSS stack.

---

## 📁 Repo Tree

```
polybot/
├── __init__.py
├── main.py                    # Entrypoint
├── requirements.txt           # All deps
├── .env.example               # Template — copy to .env
├── Dockerfile                 # Multi-stage build
├── docker-compose.yml         # With healthcheck + volume mounts
│
├── config/
│   ├── __init__.py
│   └── settings.py            # Pydantic Settings + .env loader
│
├── wallet/
│   ├── __init__.py
│   └── manager.py             # Key mgmt, EIP-712 signing, USDC allowance
│
├── exchange/
│   ├── __init__.py
│   └── polymarket.py          # CLOB REST + WS + Gamma API async client
│
├── data/
│   ├── __init__.py
│   └── ingestion.py           # Market state builder, news, on-chain signals
│
├── brain/
│   ├── __init__.py
│   ├── interface.py           # ABC + dataclasses (MarketState, Portfolio, TradeDecision)
│   └── example.py             # Placeholder brain — logs, returns []
│
├── risk/
│   ├── __init__.py
│   └── manager.py             # Sizing, exposure, kill-switch, cooldown
│
├── execution/
│   ├── __init__.py
│   └── executor.py            # Order lifecycle, retries, gas, pre-flight
│
├── scheduler/
│   ├── __init__.py
│   └── orchestrator.py        # APScheduler + asyncio + brain cycles
│
├── observability/
│   ├── __init__.py
│   ├── dashboard.py           # FastAPI + uvicorn (localhost:8080)
│   └── telegram_bot.py        # python-telegram-bot alerts + remote commands
│
├── storage/
│   ├── __init__.py
│   └── db.py                  # SQLAlchemy + SQLite models
│
└── tests/
    └── __init__.py
```

---

## 🚀 First-Run Playbook

### 1. Clone & Setup

```bash
git clone <repo> polybot
cd polybot
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure `.env`

```bash
cp .env.example .env
nano .env  # Edit your secrets
```

**Minimum required:**

```env
DRY_RUN=true
PRIVATE_KEY=0xYOUR_POLYGON_EOA_PRIVATE_KEY
# OR
MNEMONIC="your twelve word seed phrase"

POLYGON_RPC_URL=https://polygon-rpc.com
TELEGRAM_BOT_TOKEN=your_bot_token_from_BotFather
TELEGRAM_CHAT_ID=your_chat_id
```

### 3. First Run (Dry Mode)

```bash
python main.py
```

You should see:
- Wallet address + USDC balance
- Loaded markets from Polymarket Gamma
- Brain cycle running (returns empty — placeholder)
- Dashboard at http://localhost:8080
- Telegram bot responding to `/status`

### 4. Go Live (DANGER)

> ⚠️ **Only after you have tested thoroughly in DRY_RUN!**

1. Set `DRY_RUN=false` in `.env`
2. Restart bot
3. Send `/confirm_live` in Telegram
4. Bot will now execute real trades!

---

## 🛡️ Security Checklist

- [ ] `.env` is in `.gitignore` (never commit secrets)
- [ ] `PRIVATE_KEY` starts with `0x`
- [ ] `MAX_APPROVAL_USDC` is bounded (default 10,000)
- [ ] `DRY_RUN=true` for first 10+ runs
- [ ] `/killall` tested in Telegram
- [ ] Telegram `TELEGRAM_ADMIN_IDS` set to restrict commands
- [ ] RPC URL is private (Alchemy/Infura) — not public for high-frequency

---

## 🎮 Kill-Switch Operations

| Command | What It Does |
|---------|--------------|
| `/killall` | Cancel all open orders + activate kill-switch + pause brain |
| `/pause` | Pause brain cycles (no new trades) |
| `/resume` | Resume from pause |
| `/status` | Wallet, risk, dry_run status |
| `/confirm_live` | Acknowledge you're ready for live trading |

**Auto-triggers:**
- Daily loss limit hit → kill-switch + Telegram alert
- Consecutive losses → 1h cooldown
- Gas price > MAX_GAS_GWEI → reject trade

---

## 🧠 Brain Module (Your Job)

The bot ships with `brain/example.py` — a do-nothing placeholder.

**To build your strategy:**

1. Copy `brain/example.py` → `brain/my_strategy.py`
2. Implement `decide(state, portfolio) -> List[TradeDecision]`
3. Update `.env`:
   ```env
   BRAIN_MODULE=brain.my_strategy
   BRAIN_CLASS=MyStrategy
   ```
4. Restart

**Interface:**

```python
from brain.interface import BrainInterface, Portfolio, TradeDecision
from data.ingestion import MarketState
from decimal import Decimal
from typing import List

class MyStrategy(BrainInterface):
    def decide(self, state: dict[str, MarketState], portfolio: Portfolio) -> List[TradeDecision]:
        decisions = []
        for market_id, st in state.items():
            if st.latest_price and st.latest_price > Decimal("0.7"):
                decisions.append(TradeDecision(
                    market_id=market_id,
                    outcome="Yes",
                    side="BUY",
                    size=Decimal("10"),  # USDC
                    price=st.latest_price,
                    confidence=75,
                    reason="Momentum + sentiment bullish"
                ))
        return decisions
```

**Suggested follow-up brains (NOT included):**

| Brain | Description |
|-------|-------------|
| `momentum_brain` | Buy on 1h/24h price momentum crossing threshold |
| `arbitrage_brain` | Cross-exchange or cross-market price arbitrage |
| `sentiment_brain` | NLP on news/Twitter → directional bias |
| `kalman_brain` | Kalman filter mean-reversion |
| `ensemble_brain` | Weighted vote of multiple sub-brains |
| `ml_brain` | XGBoost/LightGBM on engineered features |
| `options_brain` | Kelly criterion sizing + expected value |

---

## 📡 Data Sources

| Source | Type | Free Tier |
|--------|------|-----------|
| Polymarket Gamma API | Market discovery, metadata | ✅ Unlimited |
| Polymarket CLOB | Orderbook, trades | ✅ Unlimited |
| CryptoPanic | News sentiment | ✅ 100 req/day |
| NewsAPI | General news | ✅ 100 req/day |
| RSS Feeds | Custom sources | ✅ Unlimited |
| Alchemy / Infura | Polygon RPC | ✅ Free tier |

---

## 🏗️ Docker

```bash
docker-compose up -d
```

Healthcheck pings `/health` every 30s. Logs go to `./logs/`. Database is `./polybot.db`.

---

## 🇬🇷 Greek Quickstart (Ελληνικά)

```bash
# 1. Εγκατάσταση
cd polybot
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 2. Ρύθμιση
cp .env.example .env
# Επεξεργάσου το .env — βάλε PRIVATE_KEY, TELEGRAM_BOT_TOKEN

# 3. Πρώτη εκτέλεση (ασφαλής — δεν αγοράζει τίποτα)
python main.py

# 4. Dashboard στο browser
# Άνοιξε http://localhost:8080

# 5. Telegram commands
# /status — κατάσταση
# /killall — πανικός, σταμάτα όλα
# /pause — παύση
# /resume — συνέχισε
```

---

## ⚠️ Geographic / Legal Notice

Polymarket has **jurisdictional restrictions**. Not available in all countries/regions. You must verify that your access is legal in your jurisdiction. This software is provided for educational purposes; the authors assume no liability for trading losses or regulatory issues.

---

## 🔧 Systemd (Linux 24/7)

```ini
# /etc/systemd/system/polybot.service
[Unit]
Description=PolyBot Trading Bot
After=network.target

[Service]
Type=simple
User=polybot
WorkingDirectory=/opt/polybot
ExecStart=/opt/polybot/venv/bin/python main.py
Restart=always
RestartSec=10
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable polybot
sudo systemctl start polybot
sudo systemctl status polybot
```

---

## 📊 Dashboard Endpoints

| Endpoint | Auth | Description |
|----------|------|-------------|
| `GET /health` | None | Healthcheck for Docker/systemd |
| `GET /api/status` | Bearer token | System status |
| `GET /api/heartbeats` | Bearer token | Last 100 heartbeats |
| `GET /api/decisions` | Bearer token | Last brain decisions |
| `GET /api/pnl` | Bearer token | P&L history |
| `GET /api/positions` | Bearer token | Open positions |

---

## 🧪 Testing

```bash
pytest tests/
```

---

## 📜 License

MIT — provided as-is for educational and research purposes.

---

## 🙏 Next Steps for the User

1. **Copy `.env.example` → `.env` and fill in secrets**
2. **Run in DRY_RUN mode for 1-2 days** — verify data ingestion, Telegram alerts, dashboard
3. **Build your brain** — start from `brain/example.py`, implement `decide()`
4. **Test brain with historical paper trades** — log decisions without executing
5. **Go live** — set `DRY_RUN=false`, send `/confirm_live`, start with tiny sizes
6. **Monitor** — watch Telegram, dashboard, review daily P&L summaries
7. **Iterate** — tune risk parameters, add new data sources, upgrade brain

---

**Questions?** Check `observability/telegram_bot.py` for command handlers, `risk/manager.py` for rule enforcement, and `brain/interface.py` for the brain contract.
